package com.samsung.samsungproject.domain.room.dao;

import androidx.room.Dao;

@Dao
public interface UserDao {
}
