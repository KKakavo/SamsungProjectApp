package com.samsung.samsungproject.feature.map.presentation;

import androidx.lifecycle.ViewModel;

public class MapViewModel extends ViewModel {


}
